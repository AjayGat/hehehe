package com.cg.employee.pl;

import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.service.EmployeeService;

public class MainClass {
static 	EmployeeService service=new EmployeeService();

	}

