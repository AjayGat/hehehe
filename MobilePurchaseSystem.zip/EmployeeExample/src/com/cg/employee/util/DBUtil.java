package com.cg.employee.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	static Connection con;

	static
	{
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("jdbc.properties"));
			String driver = prop.getProperty("driver");
			String url=prop.getProperty("url");
			String user=prop.getProperty("username");
			String pass=prop.getProperty("password");
			try {
				Class.forName(driver);
				try {
					con=DriverManager.getConnection(url,user,pass);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Connection getConnection(){
		return con;
	}
}
