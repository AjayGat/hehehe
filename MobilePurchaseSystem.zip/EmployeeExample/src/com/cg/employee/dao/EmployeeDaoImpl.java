package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DBUtil;

public class EmployeeDaoImpl implements IEmployeeDAO{

	
	Connection con;
	
	public EmployeeDaoImpl(){
		con=DBUtil.getConnection();
	}
	
	@Override
	public int addEmployee(Employee obj) throws EmployeeException{
		// TODO Auto-generated method stub
		
		int eid=0;
		
		
		try {
			String query="INSERT INTO CRMPune VALUES(eId_CRM.nextval,?,?,?)";
			PreparedStatement pst;
			pst = con.prepareStatement(query);
			pst.setString(1, obj.getEmpName());
			pst.setInt(2, obj.getEmpsal());
			java.sql.Date date=Date.valueOf(obj.getbDate());
			pst.setDate(3, date);
			int row=pst.executeUpdate();
			if(row>0){
			eid= getEmployeeId();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 
		return 0;
	}

	public int getEmployeeId()throws EmployeeException{
		int id=0;
		try {
		
			String qry="select eid_crm.crrval from dual";
			Statement 	stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery(qry);
			if(rs.next()){
				 id=rs.getInt(1);		
				}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return id;
		
	}
	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException{
		// TODO Auto-generated method stub
		
		ArrayList<Employee>list=new ArrayList<Employee>();
		String qry="SELECT * FROM CRMPune";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int salary=rs.getInt(3);
				LocalDate date=rs.getDate(4).toLocalDate();
				
				Employee emp=new Employee(id,name,salary,date);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public Employee getEmployeeById(int empId)throws EmployeeException {
		// TODO Auto-generated method stub
		Employee em = null;
		try {
		
			String qury="select * from CRMPune where empId=?";
			
			PreparedStatement pstmt;
			pstmt = con.prepareStatement(qury);
			pstmt.setInt(1, empId);;
			ResultSet rs= pstmt.executeQuery();

			if(rs.next()){

				int id=rs.getInt(1);
				String name=rs.getString(2);
				int salary=rs.getInt(3);
				LocalDate date=rs.getDate(4).toLocalDate();
				
			 em=new Employee(id,name,salary,date);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return em;
	}

}
