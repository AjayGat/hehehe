package com.cg.employee.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.employee.dao.IEmployeeDAO;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;


public class EmployeeService implements IEmployeeService{

	@Override
	public int addEmployee(Employee obj) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		
		String pattern="[A-Z]{1}[]a-z]{2,}";
		if(Pattern.matches(pattern, name)){
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean validateSalary(String salary) {
		// TODO Auto-generated method stub
		String pattern="[0-9]{4,6}";
		if(Pattern.matches(pattern+"", salary))
		{
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean validateEmpId(String empId) {
		// TODO Auto-generated method stub
		
		String pattern ="[0-9]{3}";
		if(Pattern.matches(pattern+"", empId)){
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean validateDate(String Date) {
		// TODO Auto-generated method stub
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bdate = LocalDate.parse(Date,format);
		if(bdate!=null)
		return true;
		else
		return false;
	}

}
