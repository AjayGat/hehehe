package com.capgemini.mobile.dao;

import java.util.ArrayList;

import com.capgemini.mobile.dto.PurchaseDetails;
import com.capgemini.mobile.dto.mobiles;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.exception.PurchaseException;

public interface IMobilePurchaseDao {

	public int	addPurchaseDetails(PurchaseDetails pd)throws PurchaseException;
	public	int countOfMobiles()throws PurchaseException;
	public void removemobileById(int mobileId)throws PurchaseException;
	public ArrayList<mobiles> viewAllMobiles() throws PurchaseException;
	public mobiles getMobileByPrice(int price)throws MobileException;

}
