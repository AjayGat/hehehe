package com.capgemini.mobile.dao;

public interface QueryMapper {

	//public static final String INSERTQUERY="INSERT INTO product VALUES (productid_seq.nextval,?,?)";
	public static final String COUNT_QUERY="SELECT COUNT(MOBILEID) FROM MOBILES";
	public static final String INSERT_QUERY="insert into purchasedetails values (?,?,?,?,sysdate,?)";
	public static final String DELETE_QUERY="DELETE MOBILES WHERE MOBILEID = ?";
	public static final String SELECT_QUERY="SELECT * FROM MOBILES";
	public static final String SELECT_MOBILE_BY_PRICE="SELECT * FROM MOBILES WHERE PRICE=?";
}
