package com.capgemini.mobile.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.mobile.dto.PurchaseDetails;
import com.capgemini.mobile.dto.mobiles;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.exception.PurchaseException;
import com.capgemini.mobile.util.DBUtil;

public class MobilePurchaseDaoImpl implements IMobilePurchaseDao {

	Connection con;

	public MobilePurchaseDaoImpl()
	{
		con = DBUtil.getConnection();
	}


	public int generatePurchaseId(){
		int purchaseId=0;
		String SQL="select purchaseid_seq.nextval from dual";
		//con=DBUtil.getConnection();
		try{
			Statement statement= con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			purchaseId = resultSet.getInt(1);
		}catch(SQLException e){
			System.out.println("problem occured while generating ProductId");
		}
		return purchaseId;
	}

	@Override
	public int addPurchaseDetails(PurchaseDetails pd) {
		// TODO Auto-generated method stub
		//con = DBUtil.getConnection();
		int purchaseId=generatePurchaseId();

		try {
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setInt(1, pd.getPurchaseId());
			pst.setString(2, pd.getcName());
			pst.setString(3, pd.getMailId());
			pst.setString(4, pd.getPhoneNo());
			pst.setInt(5, pd.getMobileId());
			pst.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return purchaseId;
	}

	@Override
	public int countOfMobiles() {
		// TODO Auto-generated method stub
		int count=0;
		String SQL="select count(mobileid) from mobiles";
		//con=DBUtil.getConnection();
		try{
			Statement statement= con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			count = resultSet.getInt(1);
		}catch(SQLException e){
			System.out.println("problem occured while generating ProductId");
		}

		return count;
	}

	@Override
	public void removemobileById(int mobileId) throws PurchaseException {
		// TODO Auto-generated method stub
		//con = DBUtil.getConnection();

		try
		{
			System.out.println(mobileId);
			PreparedStatement pst=con.prepareStatement(QueryMapper.DELETE_QUERY);
			pst.setInt(1, mobileId);
			pst.executeUpdate();
			
			
			System.out.println("Mobiles deleted ");
		}
		catch(SQLException e)
		{
			System.out.println("MOBILE id doesnt exit");
			throw new PurchaseException(e.getMessage());		
		}
	}
	/*private int mobileId;
	private String mobileName;
	private int price;
	private int quantity;*/

	@Override
	public ArrayList<mobiles> viewAllMobiles() throws PurchaseException {
		// TODO Auto-generated method stub
		ArrayList<mobiles>list = new ArrayList<mobiles>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(QueryMapper.SELECT_QUERY);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int price = rs.getInt(3);
				int quantity=rs.getInt(4);
				mobiles m=new mobiles(id,name,price,quantity);
				list.add(m);
			}
		}
		catch(SQLException e)
		{
			throw new PurchaseException(e.getMessage());
		}
		
		
		return list;
	}

	/*private int mobileId;
	private String mobileName;
	private int price;
	private int quantity;*/
	@Override
	public mobiles getMobileByPrice(int price1) throws MobileException {
		// TODO Auto-generated method stub
		mobiles mob = null;
	//	String qry = "SELECT * FROM CRMPune WHERE empId=?";
		try
		{
			PreparedStatement pst = 
					con.prepareStatement(QueryMapper.SELECT_MOBILE_BY_PRICE);
			pst.setInt(1, price1);
			ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int price = rs.getInt(3);
				int quantity=rs.getInt(4);
				 mob=new mobiles(id,name,price,quantity);
		
			}
			
		}
		catch(SQLException e)
		{
			throw new MobileException(e.getMessage());
		}
		return mob;
	}
	

}
