package com.capgemini.mobile.service;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.mobile.dao.IMobilePurchaseDao;
import com.capgemini.mobile.dao.MobilePurchaseDaoImpl;
import com.capgemini.mobile.dao.QueryMapper;
import com.capgemini.mobile.dto.PurchaseDetails;
import com.capgemini.mobile.dto.mobiles;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.exception.PurchaseException;
import com.capgemini.mobile.util.DBUtil;

public class MobilePurchaseServiceImpl implements IMobilePurchaseService{

	IMobilePurchaseDao dao=new MobilePurchaseDaoImpl();
	@Override
	public int addPurchaseDetails(PurchaseDetails pd) throws PurchaseException{
		// TODO Auto-generated method stub

		
		return dao.addPurchaseDetails(pd);
	}

	@Override
	public int countOfMobiles() throws PurchaseException {
		// TODO Auto-generated method stub
		return dao.countOfMobiles();
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		return true;
		else
			return false;
	}
	@Override
	public boolean validateMailId(String mailId) {
		// TODO Auto-generated method stub
		String  pattern="[A-Za-z0-9]{3,15}@[a-z]{5,10}.com";
		if(Pattern.matches(pattern,mailId))
			return true;
			else

		return false;
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) {
		// TODO Auto-generated method stub
		String pattern="[5-9]{1}[0-9]{9}";
		if(Pattern.matches(pattern,phoneNo))
			return true;
			else
		return false;
	}

	@Override
	public boolean validateMobileId(int mobileId) {
		// TODO Auto-generated method stub
		String pattern = "[0-9]{4}";
		if(Pattern.matches(pattern,mobileId+""))
			return true;
		else		
		return false;
	}

	@Override
	public void  removemobileById(int mobileId) throws PurchaseException {
		// TODO Auto-generated method stub
	dao.removemobileById(mobileId);
	}

	@Override
	public ArrayList<mobiles> viewAllMobiles() throws PurchaseException {
		// TODO Auto-generated method stub
		return dao.viewAllMobiles();
	}

	@Override
	public mobiles getMobileByPrice(int price) throws MobileException {
		// TODO Auto-generated method stub
		return dao.getMobileByPrice(price);
	}

}
