package com.capgemini.mobile.service;

import java.util.ArrayList;

import com.capgemini.mobile.dto.PurchaseDetails;
import com.capgemini.mobile.dto.mobiles;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.exception.PurchaseException;

public interface IMobilePurchaseService {

public int	addPurchaseDetails(PurchaseDetails Pd) throws PurchaseException;
public	int countOfMobiles() throws PurchaseException;
public void removemobileById(int mobileId)throws PurchaseException;
public ArrayList<mobiles> viewAllMobiles() throws PurchaseException;
public mobiles getMobileByPrice(int price)throws MobileException;
public boolean validateName(String cName);
public boolean validateMailId(String mailId);
public boolean validatePhoneNo(String phoneNo);
public boolean validateMobileId(int mobileId);

}
