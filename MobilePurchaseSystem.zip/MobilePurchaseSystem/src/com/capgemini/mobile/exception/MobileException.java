package com.capgemini.mobile.exception;

public class MobileException extends Exception{

	String message;
	public MobileException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}
}
