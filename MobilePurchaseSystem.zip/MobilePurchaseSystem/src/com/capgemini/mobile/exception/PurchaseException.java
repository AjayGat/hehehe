package com.capgemini.mobile.exception;

	public class PurchaseException extends Exception{
		
		String message;
		public PurchaseException(String message)
		{
			this.message = message;
		}
		@Override
		public String getMessage()
		{
			return this.message;
		}

}
