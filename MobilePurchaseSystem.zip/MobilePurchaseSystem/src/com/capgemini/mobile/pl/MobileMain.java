package com.capgemini.mobile.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.mobile.dto.PurchaseDetails;
import com.capgemini.mobile.dto.mobiles;
import com.capgemini.mobile.exception.MobileException;
import com.capgemini.mobile.exception.PurchaseException;
import com.capgemini.mobile.service.IMobilePurchaseService;
import com.capgemini.mobile.service.MobilePurchaseServiceImpl;

public class MobileMain {
	static IMobilePurchaseService service=new MobilePurchaseServiceImpl();


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Add Purchase Details");
				System.out.println("2-delete mobile by id");
				System.out.println("3-view all");
				System.out.println("4-search mobile based on price");
				System.out.println("5- delete mobile by id");
				System.out.println("search mobile based on price");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
				case 1 : 
					int count=0;
					try {
						count = service.countOfMobiles();
					} catch (PurchaseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.out.println(count);
					if(count>0)
					{
						PurchaseDetails pd= acceptPurchaseDetails(); 
						if(pd!=null){	
							try
							{
								int id = service.addPurchaseDetails(pd);
								System.out.println("inserted and id = "+id);
							}
							catch(PurchaseException e)
							{
								System.out.println(e.getMessage());
							}
						}
						else
						{
							System.err.println("No mobiles available");
						}
					}

						break;

					case 2 :
						while(true)
						{
							System.out.println("enter the mobile id to remove mobile details ");
							int mobileId=sc.nextInt();

							if(!service.validateMobileId(mobileId))
							{
								System.err.println("not valid id");
								continue;
							}
							else
							{
								try {
									service.removemobileById(mobileId);

								} catch (PurchaseException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
								
							}
							break;
						}
					

					case 3 : 
						try{ArrayList<mobiles>list = 
						service.viewAllMobiles();
						for(mobiles obj : list)
						{
							System.out.println(obj);
						}
						}
						catch(PurchaseException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
					case 4 : System.out.println("Enter price to search mobiles::");
					int price = sc.nextInt();
					try
					{
						mobiles ref = service.getMobileByPrice(price);
						System.out.println("mobile details "+ref);
					}
					catch(MobileException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					case 5:

						/*while(true){
							System.out.println("enter empId to update salary");
							int  empId=sc.nextInt();

							if(!service.validateId(empId))
							{
								System.err.println("enter valid emp id");
								continue;

							}
							else
							{
								System.out.println("enter salary to update");
								int sal=sc.nextInt();
								if(!service.validateSalary(sal))
								{
									System.err.println("enter valid salary");
								}
								try {

									service.updateEmployee(empId,sal);

								} catch (EmployeeException e) {
									// TODO Auto-generated catch block
									System.out.println(e.getMessage());
								}
							}

							break;
						}
						break;*/
					}
					System.out.println("do you want to continue 1-yes 0-No");
					choice = sc.nextInt();
				}while(choice!=0);


			}


		}
		public static PurchaseDetails acceptPurchaseDetails() {

			// TODO Auto-generated method stub
			PurchaseDetails pd = null;
			Scanner sc = new Scanner(System.in);
			while(true)
			{
				System.out.println("Enter name::");
				String cName = sc.next();
				if(!service.validateName(cName))
				{
					System.err.println("enter valid name");
					continue;
				}
				else
				{
					while(true)
					{
						System.out.println("Enter mailId::");
						String mailId = sc.next();
						if(!service.validateMailId(mailId))
						{
							System.err.println("enter valid mailId");
							continue;
						}
						else
						{
							while(true)
							{
								System.out.println("Enter phoneNo::");
								String phoneNo= sc.next();
								if(!service.validatePhoneNo(phoneNo))
								{
									System.err.println("enter valid phoneNo");
									continue;
								}
								else
								{
									while(true)
									{
										System.out.println("Enter mobileId::");
										int mobileId= sc.nextInt();
										if(!service.validateMobileId(mobileId))
										{
											System.err.println("enter valid mobileId");
											continue;
										}
										else
										{
											System.out.println("Enter date::");
											String purchaseDate = sc.next();
											DateTimeFormatter format = 
													DateTimeFormatter.ofPattern("dd/MM/yyyy");
											LocalDate pDate = LocalDate.parse(purchaseDate, format);
											if(purchaseDate!=null)
											{
												pd= new PurchaseDetails();
												pd.setcName(cName);;
												pd.setMailId(mailId);
												pd.setPhoneNo(phoneNo);
												pd.setMobileId(mobileId);
												pd.setPurchaseDate(pDate);
											
												break;
											}
										}
									}
								}
								return pd;
							}
						}
					}
				}
				
			}
			
		}
	}

