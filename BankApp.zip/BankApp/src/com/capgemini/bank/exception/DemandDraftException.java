package com.capgemini.bank.exception;

public class DemandDraftException extends Exception {
	String message;
	public DemandDraftException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}
}
