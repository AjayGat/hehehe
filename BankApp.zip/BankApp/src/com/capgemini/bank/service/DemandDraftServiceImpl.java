package com.capgemini.bank.service;

import java.util.regex.Pattern;

import com.capgemini.bank.dao.DemandDraftDaoImpl;
import com.capgemini.bank.dao.IDemandDraftDao;
import com.capgemini.bank.exception.DemandDraftException;
import com.cg.bank.bean.DemandDraft;

public class DemandDraftServiceImpl implements IDemandDraftService {

	IDemandDraftDao dao=new DemandDraftDaoImpl();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft)
			throws DemandDraftException {
		
		return dao.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)
			throws DemandDraftException {
		// TODO Auto-generated method stub
		return dao.getDemandDraftDetails(transactionId);
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		{
			return true;
		}
		else 
		
		return false;
	}

	@Override
	public boolean validateAmount(int ddAmount) {
		// TODO Auto-generated method stub

		String pattern = "[0-9]{3,9}";
		String amount = ""+ddAmount;
		System.out.println(amount);
		System.out.println(Pattern.matches(pattern,amount));
		if(Pattern.matches(pattern,amount))
		{
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) {
		// TODO Auto-generated method stub
		String pattern="[5-9]{1}[0-9]{9}";
		if(Pattern.matches(pattern,phoneNo))
			return true;
			else
		return false;
	}

	@Override
	public boolean validateFavourName(String favourName) {
		// TODO Auto-generated method stub
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,favourName))
		{
			return true;
		}
		else 
		return false;
	}

	
	
	
	

}
