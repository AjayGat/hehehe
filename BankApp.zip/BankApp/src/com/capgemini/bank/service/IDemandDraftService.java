package com.capgemini.bank.service;

import com.capgemini.bank.exception.DemandDraftException;
import com.cg.bank.bean.DemandDraft;

public interface IDemandDraftService {
public int addDemandDraftDetails(DemandDraft demandDraft)throws DemandDraftException;
public DemandDraft getDemandDraftDetails(int transactionId)throws DemandDraftException; 

public boolean validateName(String name);
public boolean validateAmount(int ddAmount);
public boolean validatePhoneNo(String phoneNo);
public boolean validateFavourName(String favourName);

}
