package com.capgemini.bank.dao;

import com.capgemini.bank.exception.DemandDraftException;
import com.cg.bank.bean.DemandDraft;

public interface IDemandDraftDao {

	public int addDemandDraftDetails(DemandDraft demandDraft)throws DemandDraftException;
	public DemandDraft getDemandDraftDetails(int transactionId)throws DemandDraftException; 
}
