package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.util.DBUtil;
import com.cg.bank.bean.DemandDraft;

public class DemandDraftDaoImpl implements IDemandDraftDao{

	Connection con;
	Logger logger = Logger.getRootLogger();


	public DemandDraftDaoImpl() {
		con = DBUtil.getConnection();
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public int generateTransactionId(){
		int transactionId=0;
		String SQL="select tid_seq.nextval from dual";
		try{
			Statement statement= con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			transactionId = resultSet.getInt(1);
		}catch(SQLException e){
			logger.error("problem occured while generating transactionId");
			System.out.println("problem occured while generating transactionId");
		}

		return transactionId;
	}

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft)
			throws DemandDraftException {
		int transactionId = generateTransactionId();
		try
		{
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setInt(1,transactionId );
			pst.setString(2, demandDraft.getcName());
			pst.setString(3, demandDraft.getInfavourOf());
			pst.setString(4, demandDraft.getPhoneNo());
			pst.setDouble(5, demandDraft.getDdAmount());
			pst.setLong(6, demandDraft.getDdCommission());
			pst.setString(7, demandDraft.getDdDesc());
			pst.executeUpdate();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("insertion failed");
			e.printStackTrace();
		}


		return transactionId;
	}

	/*private int transactionId;
	private String cName;
	private String infavourOf;
	private String phoneNo;
	private String date;
	private double ddAmount;
	private long ddCommission;
	private String ddDesc;*/
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws DemandDraftException {
		DemandDraft dem=null;
		try
		{

			PreparedStatement pst = 
					con.prepareStatement(QueryMapper.SELECT_DETAILS_BY_ID);
			pst.setInt(1, transactionId);
			ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
				int id=rs.getInt(1);
				String name = rs.getString(2);
				String inFavourOf = rs.getString(3);
				String phoneNo=rs.getString(4);
				String date=rs.getString(5);
				int ddAmount=rs.getInt(6);
				int ddCommission=rs.getInt(7);
				String ddDesc=rs.getString(8);
			 dem=new DemandDraft(id,name,inFavourOf,phoneNo,date,ddAmount,ddCommission,ddDesc);

			}
		}catch(SQLException e)
		{
			throw new DemandDraftException(e.getMessage());
		}


		return dem;
	}



	}

