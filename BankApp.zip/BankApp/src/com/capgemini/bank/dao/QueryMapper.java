package com.capgemini.bank.dao;

public interface QueryMapper {

	public static final String INSERT_QUERY="insert into demand_drafts values (?,?,?,?,sysdate,?,?,?)";
	public static final String SELECT_DETAILS_BY_ID="select * from demand_drafts where transaction_id=?";
}
