package com.cg.bank.bean;

public class DemandDraft {
	private int transactionId;
	private String cName;
	private String infavourOf;
	private String phoneNo;
	private String date;
	private int ddAmount;
	private int ddCommission;
	private String ddDesc;
	
	
	public DemandDraft() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public DemandDraft(int transactionId, String cName, String infavourOf,
			String phoneNo, String date, int ddAmount, int ddCommission,
			String ddDesc) {
		super();
		this.transactionId = transactionId;
		this.cName = cName;
		this.infavourOf = infavourOf;
		this.phoneNo = phoneNo;
		this.date = date;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDesc = ddDesc;
	}



	public DemandDraft(String cName, String infavourOf, String phoneNo,
			int ddAmount, String ddDesc) {
		super();
		this.cName = cName;
		this.infavourOf = infavourOf;
		this.phoneNo = phoneNo;
		this.ddAmount = ddAmount;
		this.ddDesc = ddDesc;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getInfavourOf() {
		return infavourOf;
	}
	public void setInfavourOf(String infavourOf) {
		this.infavourOf = infavourOf;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(int ddAmount) {
		this.ddAmount = ddAmount;
	}
	public long getDdCommission() {
		return ddCommission;
	}
	public void setDdCommission(int ddCommission) {
		this.ddCommission = ddCommission;
	}
	public String getDdDesc() {
		return ddDesc;
	}
	public void setDdDesc(String ddDesc) {
		this.ddDesc = ddDesc;
	}
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId + ", cName="
				+ cName + ", infavourOf=" + infavourOf + ", phoneNo=" + phoneNo
				+ ", date=" + date + ", ddAmount=" + ddAmount
				+ ", ddCommission=" + ddCommission + ", ddDesc=" + ddDesc + "]";
	}
	
	
}
