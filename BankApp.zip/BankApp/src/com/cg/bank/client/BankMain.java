package com.cg.bank.client;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.dao.IDemandDraftDao;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.service.DemandDraftServiceImpl;
import com.capgemini.bank.service.IDemandDraftService;



import com.cg.bank.bean.DemandDraft;

public class BankMain {
	static IDemandDraftService service=new DemandDraftServiceImpl();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");

		int choice;
		try (Scanner sc = new Scanner(System.in)) {
			do {

				System.out.println("1-Add bank Details");
				System.out.println("2-view all");
				System.out.println("3-update details");
				System.out.println("Enter choice::");
				choice = sc.nextInt();

				switch (choice) {

				case 1:
					logger.info("adding dd details");
					DemandDraft dd=acceptDemandDraftDetails();
					try
					{
						int id = service.addDemandDraftDetails(dd);
						logger.info("inserted and id = "+id);
						System.out.println("inserted and id = "+id);
					}
					catch(DemandDraftException e)
					{
						logger.error("insertion failed");
						System.err.println(e.getMessage());
					}
					logger.info("addded dd details");

					break;
				case 2:

					 
						System.out.println("Enter transaction id to get dd details::");
						int tid = sc.nextInt();
						try
						{
							DemandDraft ref = service.getDemandDraftDetails(tid);
							logger.info("dd details "+ref);
							System.out.println("dd details "+ref);
						}
						catch(DemandDraftException e)
						{
							System.out.println(e.getMessage());
						}
						break;
				case 3:

				default:
					/*******************************************
					 * -> Default case for invalid choice
					 *******************************************/
					logger.info("Invalid choice");
					System.err
					.println("You have entered an invalid choice ... Please try again!");
					break;

				}

				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();

			} while (choice != 0);

		}//try close

	}//main close

	public static DemandDraft acceptDemandDraftDetails(){

		DemandDraft dd=null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("enter the customer Name ::");
			String cName = sc.next();
			if(!service.validateName(cName))
			{
				System.err.println("enter valid name");
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("In Favour of ::");
					String inFavourOf = sc.next();
					if(!service.validateFavourName(inFavourOf))
					{
						System.err.println("enter valid name");
						continue;
					}
					else
					{
						while(true)
						{
							System.out.println("Enter phoneNo::");
							String phoneNo= sc.next();
							if(!service.validatePhoneNo(phoneNo))
							{
								logger.error("enter valid phoneNo");
								System.err.println("enter valid phoneNo");
								continue;
							}
							else
							{
								while(true)
								{
									System.out.println("enter the dd amount");
									int ddAmount=sc.nextInt();
									if(!service.validateAmount(ddAmount))
									{
										logger.error("enter valid dd amount");
										System.err.println("enter valid dd amount");
										continue;
									}
									else
									{
										int ddCommission=0;

										if(ddAmount<=5000)
										{
											ddCommission=10;
										}
										else if(ddAmount>=5001 && ddAmount<=10000)
										{
											ddCommission=41;
										}
										else if(ddAmount>=10001 && ddAmount<=100000)
										{
											ddCommission=41;
										}
										else if(ddAmount>=100001 && ddAmount<=1000000)
										{
											ddCommission=41;
										}

										System.out.println("commission "+ddCommission);
										System.out.println("Remarks ::");
										sc.nextLine();

										String ddDesc=sc.nextLine();
										if(ddDesc!=null)
										{
											dd=new DemandDraft();
											dd.setcName(cName);
											dd.setInfavourOf(inFavourOf);
											dd.setPhoneNo(phoneNo);
											dd.setDdAmount(ddAmount);
											dd.setDdCommission(ddCommission);
											dd.setDdDesc(ddDesc);

											break;
										}

									}

								}
							}
							return dd;
						}
					}
				}
			}





		}
	}//accept method close
}//class close
