package com.capg.student.service;

import java.util.ArrayList;

import com.capg.student.dto.Student;
import com.capg.student.exception.StudentException;

public interface IStudentService {
	
public int addStudentDetails(Student st) throws StudentException;
public ArrayList<Student> viewAllStudentDetails() throws StudentException;

public boolean validateName(String name);
public boolean validateStudentId(int studentId);
public boolean validateAge(int age);
public boolean validateMarks(int marks);

}
