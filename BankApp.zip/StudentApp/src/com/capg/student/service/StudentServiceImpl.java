package com.capg.student.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capg.student.dao.IStudentDao;
import com.capg.student.dao.StudentdaoImpl;
import com.capg.student.dto.Student;
import com.capg.student.exception.StudentException;

public class StudentServiceImpl implements IStudentService{
IStudentDao dao=new StudentdaoImpl();
	@Override
	public int addStudentDetails(Student st) throws StudentException {
		// TODO Auto-generated method stub
		return dao.addStudentDetails(st);
	}

	@Override
	public ArrayList<Student> viewAllStudentDetails() throws StudentException {
		return dao.viewAllStudentDetails();
	}

	@Override
	public boolean validateName(String name) {
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		{
			return true;
		}
		else 
		return false;
	}

	@Override
	public boolean validateStudentId(int studentId) {
		String pattern = "[0-9]{4}";
		if(Pattern.matches(pattern,studentId+""))
			return true;
		else	
		return false;
	}

	@Override
	public boolean validateAge(int age) {
		if(age>=5 && age<=21)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateMarks(int marks) {
		if(marks>=0 && marks<=100)
		{
			return true;
		}
		
		return false;
	}

}
