package com.capg.student.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Student {
private	int studentId;
private	String sName;
private	int age;
private	LocalDate dob;
private	int marks;
private	String grade;


public Student() {
	super();
	// TODO Auto-generated constructor stub
}


public Student(String sName, int age, LocalDate dob, int marks) {
	super();
	this.sName = sName;
	this.age = age;
	this.dob = dob;
	this.marks = marks;
}

public Student(int studentId, String sName, int age, LocalDate dob, int marks,
String grade) {
	super();
	this.studentId = studentId;
	this.sName = sName;
	this.age = age;
	this.dob = dob;
	this.marks = marks;
	this.grade = grade;
}
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getsName() {
	return sName;
}
public void setsName(String sName) {
	this.sName = sName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", sName=" + sName + ", age="
			+ age + ", dob=" + dob + ", marks=" + marks + ", grade=" + grade
			+ "]";
}


}
