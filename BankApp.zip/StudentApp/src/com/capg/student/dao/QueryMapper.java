package com.capg.student.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="insert into students values (?,?,?,?,?,?)";
	public static final String SELECT_QUERY="SELECT * FROM STUDENTS";
}
