package com.capg.student.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capg.student.dto.Student;
import com.capg.student.exception.StudentException;
import com.capg.student.util.DBUtil;

public class StudentdaoImpl implements IStudentDao{

	Connection con;
	Logger logger = Logger.getRootLogger();
	
	public StudentdaoImpl()
	{
		con = DBUtil.getConnection();
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	public int generateStudentId()
	{
		int SId=0;
		String SQL="select sid_seq.nextval from dual";
		
		try
		{
			Statement statement= con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			SId = resultSet.getInt(1);
			System.out.println("generated id ::"+SId);
		}catch(SQLException e){
			logger.error("problem occured while generating ProductId");
			System.out.println("problem occured while generating ProductId");
		}
		
		
		return SId;
		
		
	}
	
	@Override
	public int addStudentDetails(Student st) throws StudentException {
		
		int sid=generateStudentId();
		
		System.out.println("generated id  in add method::"+sid);
		LocalDate bDate = st.getDob(); 
		java.sql.Date date = java.sql.Date.valueOf(bDate);
		try
		{
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setInt(1, sid);
			pst.setString(2,st.getsName());
			pst.setInt(3, st.getAge());
			pst.setDate(4, date);
			pst.setInt(5, st.getMarks());
			String grade = ""+st.getGrade();
			pst.setString(6, grade);
			pst.executeUpdate();

		}catch(SQLException e)
		{
			logger.error("insertion failed");
			e.printStackTrace();
		}
	
		
		return sid;
	}

	@Override
	public ArrayList<Student> viewAllStudentDetails() throws StudentException 
	{
		ArrayList<Student>list=new ArrayList<Student>();
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(QueryMapper.SELECT_QUERY);
			
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int age=rs.getInt(3);
				Date date=rs.getDate(4);
				int marks=rs.getInt(5);
				String grade=rs.getString(6);
				LocalDate bdob=date.toLocalDate();
				
				Student stu=new Student(id,name,age,bdob,marks,grade);
		        list.add(stu);
				
			}
		}
		catch(SQLException e)
		{
			throw new StudentException(e.getMessage());
		}
		return list;
	}

	

}
