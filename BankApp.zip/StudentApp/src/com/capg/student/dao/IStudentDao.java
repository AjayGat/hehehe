package com.capg.student.dao;

import java.util.ArrayList;

import com.capg.student.dto.Student;
import com.capg.student.exception.StudentException;

public interface IStudentDao {
	public int addStudentDetails(Student st) throws StudentException;
	public ArrayList<Student> viewAllStudentDetails() throws StudentException;
}
