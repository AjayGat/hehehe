package com.capg.student.pl;



import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capg.student.dao.StudentdaoImpl;
import com.capg.student.dto.Student;
import com.capg.student.exception.StudentException;
import com.capg.student.service.IStudentService;
import com.capg.student.service.StudentServiceImpl;

public class StudentMain {
	static IStudentService service=new StudentServiceImpl();

	static Logger logger=Logger.getRootLogger();
	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");

		int choice;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Add Student Details");
				System.out.println("2-view all Student Details");
				System.out.println("Enter choice::");
				choice = sc.nextInt();

				switch(choice)
				{

				case 1 :

					/*******************************************
					 -> Case for adding purchase details
					 *******************************************/
					Student st=acceptStudentDetails();
					if(st!=null)
					{
						try
						{
							int id = service.addStudentDetails(st);
							logger.info("inserted and student id = "+id);
							System.out.println("inserted and student id = "+id);
						}
						catch(StudentException e)
						{
							logger.error("insertion failed");
							System.err.println(e.getMessage());
						}
					}

					break;
				case 2 :
					/*******************************************
					 -> Case for view all student details
				 *******************************************/
				try{ArrayList<Student>list = 
				service.viewAllStudentDetails();
			
				for(Student obj : list)
				{
					System.out.println(obj);
				}
				}
				catch(StudentException e)
				{
					System.out.println(e.getMessage());
				}
					break;
				default:
					/*******************************************
						 -> Default case for invalid choice 
					 *******************************************/
					logger.info("Invalid choice");
					System.err.println("You have entered an invalid choice ... Please try again!");
					break;

				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();

			}while(choice!=0);


		}//try close






	}//main method close


	public static Student acceptStudentDetails()
	{
		Student st=null;
		Scanner sc= new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name::");
			String sName = sc.next();
			if(!service.validateName(sName))
			{
				System.err.println("enter valid name");
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter age::");
					int age = sc.nextInt();
					if(!service.validateAge(age))
					{
						System.err.println("enter valid age");
						continue;
					}
					else
					{
						while(true)
						{
						System.out.println("Enter marks::");
						int marks = sc.nextInt();
						if(!service.validateMarks(marks))
						{
							System.err.println("enter valid marks");
							continue;
						}
						else
						{
							String grade=" ";

							if(marks<60)
							{
								grade="D";
							}
							else if(marks>60 && marks<70)
							{
								grade="D";
							}
							else if(marks>70 && marks<85)
							{
								grade="B";
							}
							else if(marks>85 && marks<100)
							{
								grade="A";
							}
							System.out.println("generated grade"+grade);
							System.out.println("Enter date of birth::");
							String date = sc.next();
							DateTimeFormatter format = 
									DateTimeFormatter.ofPattern("dd/MM/yyyy");
							LocalDate bdate = LocalDate.parse(date, format);
							if(bdate!=null)
							{
								st=new Student();
								st.setsName(sName);
								st.setAge(age);
								st.setDob(bdate);
								st.setMarks(marks);
								st.setGrade(grade);

								break;
							}

							}
						}

					}//2nd
					return  st;

				}
			}


		}


	}//accept method close


}//class close
